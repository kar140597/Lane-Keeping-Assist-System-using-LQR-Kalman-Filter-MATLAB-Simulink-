clc
close all
clear all

%% Definition of Equilibrium
%Parameters
syms  u V_y real
nus = 0;
rs = 0.1;%ref*
m = 1573;
I_z = 2873;
a = 1.1;
b = 1.58;
r_ws = 0;
yds = rs;
psi_s = 0;
C_fs = 80000;
C_rs = 80000 ;
V_xs = 16.667;
%V_ys= 0;
% slip angles
alpha_f = u - (V_y + a*r_ws)/V_xs;
alpha_r = - (V_y - b*r_ws)/V_xs;

% tyre forces
F_f = 2*C_fs*alpha_f;
F_r = 2*C_rs*alpha_r;

% dynamics
dot_V_y = (-m*V_xs*r_ws + F_f + F_r)/m;
dot_r_w = (a*F_f - b*F_r)/I_z;

% solve steady-state
sol = solve([dot_V_y == 0,dot_r_w == 0], [V_y,u]);



% Eqilibrium equation
V_ys = double(sol.V_y);
us  = double(sol.u);
%V_ys = double(sol.V_y);

xs = [V_ys;r_ws;psi_s;yds];

ds = [C_fs;C_rs];


ws = [ds;nus;rs];

ys = yds + nus;

es = rs - (yds + nus);

x0 = [0;0;0;0];

%% Linearization Model

%state linearization
Amatrix = A(C_fs,C_rs,I_z,V_xs,a,b,m);
B1matrix = B1(C_fs,I_z,a,m);
B2matrix = B2(I_z,V_xs,V_ys,a,b,m,r_ws,us);

% output linearization
Cmatrix = C;
D1matrix = D1;
D2matrix = D2;

%error linearization
Cematrix = Ce;
De1matrix = De1;
De2matrix = De2;

%state space
n = length(Amatrix);
[~ , p] = size(B1matrix);
[~ , r] = size(B2matrix);
[q,~] = size(Cmatrix);
[s,~] = size(Cematrix);

%% LQR statefeedback with integral action

Ae = [Amatrix  zeros(n,s);
      Cematrix  zeros(s,s)];

B1e = [B1matrix;
       De1matrix;];

alpha = 1;%<
umax=2.12;%2.12<
Ceps = eye(size(Ae));

R = 1/umax^2;%umax=1

eps1max=1;
eps2max=1;
eps3max=1; 
eps4max=1;
eps5max=0.01;% 0.012
Q = inv(length(Ceps)*diag([eps1max^2;eps2max^2;eps3max^2;eps4max^2;eps5max^2]));

Deps = zeros(length(Ae),p) ;
barR = Deps.'*Q*Deps + R;
Am = Ae + alpha*eye(size(Ae));
Bm = B1e;
Qm = Ceps.'*Q*Ceps; % to penalise the cost
Rm = barR;
Sm = (Deps.'*Q*Ceps).';
Em = eye(size(Ae));
Gm = 0;


[Xm,Km,Lm] = icare(Am,Bm,Qm,Rm,Sm,Em,Gm);

K = -Km;
Ks = K(1:length(Amatrix))
KIA = K(length(Amatrix)+1:end)
%Ks = zeros(1,2); %test stabilizer

%% Observer via Kalman Filter

alphad =1;

sigma_C_f = 0.1*C_fs;% variation expected

sigma_C_r = 0.1*C_fs ;% variation expected

Qd11 = diag([sigma_C_f^2,sigma_C_r^2]);% disturbance relavance

sigma_nu = 1e-3;% closer to system noise in real world

Qd22 = sigma_nu^2; % noise sensor impact

Qd12 = zeros(2,1); % cross co relation between diturbances and noise. Is noise imacpeted by disturbance?

Qd = [Qd11 Qd12 zeros(2,1)

 Qd12.' Qd22 zeros(1)
 zeros(1,4)];% not considered reflation btw disturbance and referece

Rd = 1e-3*eye(q);

barRd = D2matrix*Qd*D2matrix.' + Rd; % influence of sensor noise

Am = Amatrix.' + alphad*eye(size(Amatrix));
Bm = Cmatrix.';
Qm = B2matrix*Qd*B2matrix.'; % to penalise the cost
Rm = barRd;
Sm = (D2matrix*Qd*(B2matrix).').';
Em = eye(size(Amatrix));
Gm = 0;

[XmO,KmO,LmO] = icare(Am,Bm,Qm,Rm,Sm,Em,Gm);%

Ko = KmO.' % result depend on dynamic changes accpeted how greater it is sigma
             %Lower Ko the model is more beliveable, Ko become agressive to
             %match sensor efficiency when noise is smaller

%Ko = zeros(1,2); %test stabilizer


Ae_cl = Ae + B1e * [Ks KIA];
Ks_eig = eig(Ae_cl);

Aobs  = Amatrix - Ko*Cmatrix;
Ko_eig = eig(Aobs)

%% Simulation

model = 'Lane_Keeping_Assistance_System.slx';

% Load model
load_system(model);

% Run simulation
simOut = sim(model,'StopTime','100');

% Show scopes / open model
open_system(model);