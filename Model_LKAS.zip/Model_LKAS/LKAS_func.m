clc
close all
clear all

%% declaration

syms V_y r_w psi yd real % X
syms C_f C_r real % d
syms r u nu real % ref,control, sensor noise
syms V_x real % longitudinal speed
syms a b real % CG distances
syms m I_z real % mass,inertia
%% Prameters
x = [V_y;r_w;psi;yd];% state
d = [C_f;C_r];% disturbance
w = [d;nu;r];% exogenous

%% Function
% slip angles
alpha_f = u - (V_y + a*r_w)/V_x;
alpha_r = - (V_y - b*r_w)/V_x;

% tyre forces
F_f = 2*C_f*alpha_f;
F_r = 2*C_r*alpha_r;

% dynamics
dot_V_y = (-m*V_x*r_w + F_f + F_r)/m;
dot_r_w = (a*F_f - b*F_r)/I_z;
dot_psi = r_w;
dot_y = V_y + V_x*psi;

%function

f = [ dot_V_y;dot_r_w;dot_psi;dot_y];% f

h =[yd + nu;psi+nu]; % output function

he = r -(yd + nu); % error function
%% Linearisation
% state
A = jacobian(f,x);
B1 = jacobian(f,u);
B2 = jacobian(f,w);
%output
C = jacobian(h,x);
D1 = jacobian(h,u);
D2 = jacobian(h,w);
%Error
Ce = jacobian(he,x);
De1 = jacobian(he,u);
De2 = jacobian(he,w);

%% Numerical Form
% state
matlabFunction(A,'File','A');
matlabFunction(B1,'File','B1');
matlabFunction(B2,'File','B2');
%output
matlabFunction(C,'File','C');
matlabFunction(D1,'File','D1');
matlabFunction(D2,'File','D2');
%Error
matlabFunction(Ce,'File','Ce');
matlabFunction(De1,'File','De1');
matlabFunction(De2,'File','De2');
