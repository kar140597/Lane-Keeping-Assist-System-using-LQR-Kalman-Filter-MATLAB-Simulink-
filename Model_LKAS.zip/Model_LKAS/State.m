syms V_y u r_ws real

% parameters
rs  = 0.01;
r_ws = rs;
C_f = 80000;
C_r = 80000;
V_xs = 16.667;
m   = 1573;
Iz  = 2873;
a   = 1.1;
b   = 1.58;

% slip angles
alpha_f = u - (V_y + a*r_ws)/V_xs;
alpha_r = - (V_y - b*r_ws)/V_xs;

% tyre forces
F_f = 2*C_fs*alpha_f;
F_r = 2*C_rs*alpha_r;

% dynamics
dot_V_y = (-m*V_xs*r_ws + F_f + F_r)/m;
dot_r_w = (a*F_f - b*F_r)/Iz;

% solve steady-state
sol = solve([dot_V_y == 0, dot_r_w == 0], [V_y, u]);

V_ys = double(sol.V_y);
u_s  = double(sol.u);
