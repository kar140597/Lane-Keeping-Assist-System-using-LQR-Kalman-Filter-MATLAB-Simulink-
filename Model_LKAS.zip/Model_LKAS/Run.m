syms K_vy K_rw lambda ;
syms V_y r_w real % X
syms C_f C_r real % d
syms r u nu real % ref,control, sensor noise
syms V_x real % longitudinal speed
syms a b real % CG distances
syms m I_z real % mass,inertia

x = [V_y;r_w];% state
d = [C_f;C_r];% disturbance
w = [d;nu;r];% exogenous

%% Function
f = [ (((2*C_f*(u-(V_y/V_x)-(a*r_w)))+(2*C_r*((-V_y/V_x)+(b*r_w))))/m)-(V_x*r_w);
    (((2*a*C_f)*((u-(V_y/V_x)-(a*r_w)))-(2*b*C_r*((-V_y/V_x)+(b*r_w)))))/I_z ];% f

A = jacobian(f,x);
B1 = jacobian(f,u);

q = A +B1*[K_vy  K_rw];

charpoly = det(q - lambda*eye(2));
p = simplify(charpoly);

[Num,Den] = numden(p);              % get numerator and denominator
Num = expand(Num);                  % expand numerator
Num_collected = collect(Num, lambda)

% Get coefficients of lambda^2, lambda, lambda^0
coeffs_lambda = coeffs(Num_collected, lambda);
a2 = coeffs_lambda(end);            % λ^2 coefficient (should be I_z*V_x*m)
a1 = coeffs_lambda(end-1);          % λ coefficient
a0 = coeffs_lambda(end-2);          % constant term

alpha = simplify(a1 / a2);
beta  = simplify(a0 / a2);

eigpoly = eig(q - lambda*eye(2))
kvy = solve(eigpoly,K_vy)
